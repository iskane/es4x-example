var lodash = require('META-INF/resources/webjars/lodash/4.17.15/lodash.js');
vertx.eventBus().consumer("hello.vertx.addr", function(msg) {
  msg.reply("Hello Vert.x World from JavaScript!");
});